"""Vendored exact inference sources."""
