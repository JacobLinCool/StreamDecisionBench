"""Exact Decision 2.0 model sources."""
